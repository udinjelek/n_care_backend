# app/config.py
class Config:
    API_ENDPOINT = 'http://127.0.0.1:5001/'
    BEARER_TOKEN = 'your_bearer_token_here..'
    UPLOAD_FOLDER = 'app/upload'
    GLOBAL_FILE = 'download'
    